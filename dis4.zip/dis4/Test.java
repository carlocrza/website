public class Test {
	public static void main(String[] args) {
		Animal a = new Animal("Ralph", 3);
		Cat c = new Cat("Tubbs", 5);
		a.greet();
		c.greet();
	}
}