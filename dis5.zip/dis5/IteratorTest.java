import java.util.Iterator;

public class IteratorTest implements Iterator<Integer> {
	public int next() {
		return 5;
	}
	public boolean hasNext() {
		return true;
	}
}