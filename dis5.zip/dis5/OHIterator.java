import java.util.Iterator;
import java.util.NoSuchElementException;

public class OHIterator implements Iterator<OHRequest> {
    OHRequest curr;
    
    public OHIterator(OHRequest queue) {
        curr = queue;
    }
    
    public boolean isGood(String description) {
        return description != null && !description.equals("") && description.length() > 5;
    }
    
    @Override
    public boolean hasNext() {
        while (curr != null && !isGood(curr.description)) {
            curr = curr.next;
        }
        return curr != null;
    }

    @Override
    public OHRequest next() {
        // this if statement is 'optional' tho recommended
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        OHRequest currRequest = curr;
        curr = curr.next;
        return currRequest;
    }

    // just playing around
    public static void main(String[] args) {
        OHRequest req = new OHRequest("need help", "carlo", null);
        req = new OHRequest("need help", "bobby", req);
        req = new OHRequest("need help", "cathy", req);
        System.out.println(req.name);
        System.out.println(req.next.name);
        System.out.println(req.next.next.name);
        OHIterator iter = new OHIterator(req);
        System.out.println(iter.hasNext());
        System.out.println(iter.hasNext());
        System.out.println(iter.hasNext());
        System.out.println(iter.hasNext());
        while (iter.hasNext()) {
            System.out.println(iter.next().name);
        }
        iter.next();

        OfficeHoursQueue q = new OfficeHoursQueue(req);
    }
}