import java.util.NoSuchElementException;
public class TYIterator extends OHIterator {
    boolean skipNext = false;
    
    public TYIterator(OHRequest queue) {
        super(queue);
    }

    @Override
    public boolean hasNext() {
        if (curr != null && skipNext) {
            curr = curr.next;
            skipNext = false;
        }
        return super.hasNext();
    }

    @Override
    public OHRequest next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        if (curr.description.contains("thank u")) {
            skipNext = true;
        }
        return super.next();
    }

    public static void main(String[] args) {
        OHRequest req = new OHRequest("need help", "e", null);
        req = new OHRequest("need help", "d", req);
        req = new OHRequest("thank u", "c", req);
        req = new OHRequest("thank u", "b", req);
        req = new OHRequest("need help", "a", req);
        TYIterator iter = new TYIterator(req);
        System.out.println(iter.next().name);
        System.out.println(iter.next().name);
        System.out.println(iter.next().name);
        System.out.println(iter.next().name);
        System.out.println(iter.next().name);
    }
}