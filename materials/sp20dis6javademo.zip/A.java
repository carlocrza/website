class A {
   int a = 5;

   int x() {
      return 5;
   }

   private int x = -1;
   void setX(int y) {
      this.x = y;  // this.x
   }
   int getX() {
      return this.x; // this.x
   }
}