class B extends A {
   int x() {
      return 10;
   }
   int a = 10;

   static int z = 9;
}