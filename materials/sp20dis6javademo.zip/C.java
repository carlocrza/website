class C extends B {
   int x() {
      return a; // this.a
   }

   int a = 999;
}