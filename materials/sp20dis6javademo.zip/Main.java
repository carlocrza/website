class Main {

// class A {
//    int a = 5;

//    int x() {
//       return 5;
//    }

//    private int x = -1;
//    void setX(int y) {
//       this.x = y;  // this.x
//    }
//    int getX() {
//       return this.x; // this.x
//    }
// }

// class B extends A {
//    int x() {
//       return 10;
//    }
//    int a = 10;

//    static int z = 9;
// }

// class C extends B {
//    int x() {
//       return a; // this.a
//    }

//    int a = 999;
// }

public static void main(String[] args){
   // Many things are going on. 
   // You can uncomment/comment things to more closely trace what's happening.
   
   A b0 = new B();
   System.out.println(b0.a);


   A c = new C();

   // System.out.println(c.x); // error x has private access in A
   c.setX(123);
   System.out.println(c.getX());
}

}